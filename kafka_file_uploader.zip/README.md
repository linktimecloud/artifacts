# kafka-file-uploader
A demo to upload and produce file text content to Kafka for BDOS user-defined Docker application.
